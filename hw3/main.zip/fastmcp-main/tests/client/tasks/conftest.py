"""Shared fixtures for client task tests."""

# Task protocol is now always enabled - no fixture needed
